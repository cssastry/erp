module.exports = {
    mongoConnection: "mongodb://127.0.0.1:27017/erp",
    PORT: 3003,
}